	import java.util.Scanner;
public class Task2_Bank {
	
		static double balance=0.0;

	public static void deposit() {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the amount you want to deposit: ");
		double amount= scan.nextDouble();
		 balance += amount;
		System.out.println("Your balance after the deposit is: "+ balance);
	}

	public static void withdraw() {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the amount you want to withdraw: ");
		double amount= scan.nextDouble();
		if (amount<= balance) {
		balance-= amount;
		System.out.println("Your balance after the withdrawell is: "+ balance);
		}
		System.out.println("You do not have enough money");
	}

	public static void checkBalance() {
		System.out.println("Your balance is: "+ balance);
	}
	public static void main(String []args) {
		Scanner scan = new Scanner(System.in);
		int actions;
		do {
			System.out.println("What action do you wnat to do? \n 0:exit \n 1:deposit \n 2:withdraw\n 3:chek the balance");
			 actions= scan.nextInt();
		
		switch(actions) {
		case 0:
			 System.out.println("Thank you for using the banking app. Goodbye!");
			 break;
		case 1:
			 deposit();
			 break;	 
		case 2:
			 withdraw();
			 break;	 
		case 3:
			 checkBalance();
			 break;
		default:
	        System.out.println("Invalid choice. Please try again.");
		}
		} while(actions !=0);
		
		scan.close();
	}

	}


